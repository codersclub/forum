<?php

$lang = array (
'global_poll'		=>	"Global Poll",
'poll_you_voted'       	=> 	"You already voted in this poll",
'poll_you_created' 	=> 	"You started this poll - you are not allowed to vote",
'poll_no_guests'	=>	"Guests must not vote - please login",
'topic_locked'		=>	"The Poll is locked",
'poll_add_vote'		=>	"Add your vote to this poll",
'poll_null_vote'	=>	"Null Vote",
'poll_topic'		=>	"Poll Topic",
'by'			=>	"by",
'pv_total_votes' => "Total Votes",

);
?>