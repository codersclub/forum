<?php

$lang = array (

'multi_pages' => "Pages:",
'disallow_rep' => "[Voting <font color='red'>disallowed</font>!]",

'add_success' => "reputation successfully added.",
'rem_success' => "reputation successfully removed.",
'del_success' => "this reputation change undone.",

'no_post_right' => "the user's posting rights have been removed, due to low reputation.",

'ptitle' => "Changing Reputation",
'pnav' => "Changing Reputation",
'stitle' => "Reputation Changes Statistics",
'snav' => "Reputation stats",
'btitle' => "Board overall statistics",
'bnav' => "Board overall Reputation stats",
'fill' => "Please fill this form",
'yourname' => "Your name:",
'whosename' => "Changing reputation of:",
'reason' => "The reasons to change reputation:",
'go' => "Go!",
'act' => "Type:",
'raise' => "Raise reputation",
'lower' => "Lower reputation",

'user' => ":: Member",
'who' => "From user",
'whom' => "To user",
'where' => "For a post in topic",
'why' => "Reason",
'code' => "Rating",
'when' => "Date",

'undo_change' => "Undo this change",
'back' => "Back",
'no_changes' => "Empty",
'allow_anon' => "[Anonymous voting allowed]",
'disallow_anon' => "[Anonymous voting <font color='red'>disallowed</font>]",

'no_topic' => "Moved or deleted",
'vote_anon' => "Be anonymous",
'is_anon' => "Anonymous",

'has_changed' => "has rated others",
'has_times' => "times",

'sort_by_name' => "Names",
'sort_by_rep' => "Got Votes",
'sort_by_rep_changes' => "Given Votes",
'descending_order' => "Descending Order",
'ascending_order' => "Ascending Order",
'sorting_text' => "Showing by <#SORT_KEY#> in <#SORT_ORDER#> with <#MAX_RESULTS#> results per page",
'sort_submit' => "OK!",

'member' => "Member Name",
'given' => ", given",
'details' => "[Details]",

'len_max' => "Maximum allowed length of the message is: ",
'len_current' => " symbols. So far you have used ",
'len_symbols' => " symbols",

);
?>