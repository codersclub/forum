<?php

$lang = array (

'who_farted'    => "Who posted in:",
'no_forums'     => "View Forums (%s total...)",

'who_poster'    => "Poster",
'who_posts'     => "Posts",
'who_go'        => "Close window & open topic",

'todays_posters'   => "Todays Top 10 Posters",
'member'           => "Member",
'member_posts'     => "Total Member Posts",
'member_today'     => "Posts Today",
'member_joined'    => "Joined",
'member_percent'   => "% of todays posts",
'total_today'      => "Total posts today: ",
'no_info'          => "No information is available at this time",

'top_poster_title'       => "Todays top 10 posters",


'forum_leaders'          => "The moderating team",

'leader_admins'          => "Administrators",
'leader_global'          => "Global Moderators",
'leader_mods'            => "Forum Moderators",


'leader_name'            => "Member Name",
'leader_email'           => "Email",
'leader_aol'             => "AOL",
'leader_icq'             => "ICQ",
'leader_location'        => "Location",
'leader_forums'          => "Forums",
'leader_all_forums'      => "All Forums",



);
?>