<?php

$lang = array (

'end'					=>	"end",
'forum'					=>	"Forum",
'on	'				    =>	"on",
'title'					=>	"Printable Version of Topic",
'by'				    =>	"Posted by",
'start'					=>	"started by",
'topic'					=>	"Topic",
'tvo_title'             =>  "Topic View Options for:",
'o_print_title'         =>  "Printer Friendly Version",
'o_print_desc'          =>  "This will display the topic in a simple, printer friendly format on this page, no download is required.",
'o_html_title'          =>  "Download HTML Version",
'o_html_desc'           =>  "This will enable you to download a HTML version of this topic to your hard drive. This will open your browser's download dialogue box",
'o_word_title'          =>  "Download Microsoft Word Version",
'o_word_desc'           =>  "This will enable you to download a version of this topic in an editable Word format. This will open your browser's download dialogue box",
'back_topic'            =>  "Back to the topic",
'topic_here'            =>  "Click here to view this topic in its original format",
);
?>