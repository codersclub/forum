<?php
$lang = array (
 
WHERE_Statistics => "Viewing Statistics", 


	);

?>