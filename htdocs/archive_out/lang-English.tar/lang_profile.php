<?php

$lang = array (

// Song
//Reputation
'rep_details' => "[details >>]",
//Reputation
// Song


//added 1.2 b3
'integ_msg'    => "Integrity Messenger",

// 1.2

'rating_level' => "Rating",
'warn_level'   => "Warn Level",
'photo_title'  => "Photo",
'ac_close'     => "Close card",
'ac_download'  => "Download this card",



//--


'user_local_time' => "User's local time",

'head_title'   => "Viewing Profile",

'head_contact' => "Contact Details",

'head_posts'   => "Posting Information",

'head_info'    => "Member Information",

'no_info'      => "<i>No Information</i>",

'click_here'   => "<i>Click Here</i>",
'private'      => "<i>Private</i>",

'active_stats' => "Active Stats",

'total_posts'   => "Total Cumulative Posts",
'joined'        => "Joined",
'posts_per_day'  => "Posts per day",
'total_percent'  => "of total forum posts",
'fav_forum'      => "Most active in",
'fav_posts'      => "posts in this forum",
'fav_percent'    => "of this member's active posts",

'communicate'    => "Communicate",
"info"           => "Information",
'post_detail'    => "Posting Details",

"back"  => "back",

'email'   => "Email",
'aim'     => "AIM Name",
'icq'     => "ICQ Number",
'yahoo'   => "Yahoo Identity",
'msn'     => "MSN Identity",
'pm'      => "Personal Message",

'page_title' => "Viewing Profile",

'find_posts'  => "Find all posts by this member",
'find_topics'  => "Find all topics by this member",
'add_to_contact' => "Add to contact list",

'edit_my_sig'    => "Edit my Signature",
'edit_profile'   => "Edit my Profile",
'edit_avatar'    => "Avatar Options",


'mgroup'  => "Member Group",
'mtitle'  => "Member Title",
'homepage'=> "Home Page",
'birthday' => "Birthday",
'location' => "Location",
'interests' => "Interests",
'avatar'    => "Avatar",
'siggie'    => "Signature",

);
?>