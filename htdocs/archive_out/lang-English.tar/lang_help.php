<?php

$lang = array (

topic_text					=>	"Here is the topic you chose to view",
results_title					=>	"Your Help Search Results",
choose_file					=>	"Choose a topic",
help_txt					=>	"Welcome to the help database.<br><br>Simply choose from one of the titles to learn more about how this board works. Or, simply search for help files",
submit					=>	"Search!",
search_txt					=>	"Enter keywords to search for",
search_results					=>	"Search Results",
results_txt					=>	"Here are the results of the search you performed.",
help_topics					=>	"Help Topics",
no_results					=>	"Sorry, we could not find any help topics that matched your search criteria, please try again",
help_topic					=>	"Help Topic",
page_title					=>	"Help Files",
);
?>