<?php

$lang = array (

//added 1.2

'member_photo'  => "Photo",

'ch_begins'     => "Name begins with",
'ch_contains'   => "Name contains",
'ch_all'        => "Search All Available",
'qs_go'         => "Go!",
'pages'         => "Pages:",
'photo_only' => "Show matches with photo only?",



member_group					=>	"Group",
member_aol					=>	"AOL",
sort_by_name					=>	"Member Name",
sort_by_rep					=>	"Reputation",
sort_by_dgm					=>	"DigiMoney",
sort_by_location  				=> 	"Town",
member_joined					=>	"Joined",
member_location  				=> 	"Town",
member_icq					=>	"ICQ",
sorting_text					=>	"Showing <#FILTER#> by <#SORT_KEY#> in <#SORT_ORDER#> with <#MAX_RESULTS#> results per page",
member_name					=>	"Name",
member_posts					=>	"Posts",
multi_pages					=>	"Multiple Pages",
sort_by_posts					=>	"Total Posts",
descending_order					=>	"Descending Order",
ascending_order					=>	"Ascending Order",
show_admin					=>	"Administrators",
member_level					=>	"Level",
sort_submit					=>	"Go!",
show_all					=>	"All Members",
member_email					=>	"Email",
sort_by_joined					=>	"Join Date",
sort_by_level					=>	"Member Level",
show_staff					=>	"Board Staff",
page_title					=>	"Member List",
);
?>