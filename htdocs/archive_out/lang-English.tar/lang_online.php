<?php

$lang = array (

// 1.2

's_by'    => "Sort by: ",
's_sort_key_click' => "Last Click",
's_sort_key_name'  => "Member Name",
's_sort_order_asc'   => "Ascending",
's_sort_order_desc'  => "Descending",
's_show_mem_guest' => "Show Guests Only",
's_show_mem_reg' => "Show Registered Only",
's_show_mem_all'    => "Show All Users",
's_go' => "Update",
WHERE_SF					=>	"Viewing Forum:",
WHERE_SR					=>	"Viewing Forum Rules:",
WHERE_ST					=>	"Viewing Topic:",
WHERE_Login				=>	"Logging in...",
WHERE_Post				=>	"Posting in forum:",
WHERE_Reg	 				=>	"Registering...",
WHERE_Online				=>	"Viewing Online List",
WHERE_Members				=>	"Viewing the Members List",
WHERE_Help				=>	"Viewing the Help Files",
WHERE_Search				=>	"Searching...",
WHERE_Print				=>	"Printing Topic:",
WHERE_Forward				=>	"Emailing topic:",
WHERE_Msg				=>	"Using Personal Messenger",
WHERE_UserCP				=>	"Using User CP",
WHERE_Mail	 				=>	"Contacting member via email",
WHERE_Invite				=>	"Inviting a friend to the board",
WHERE_ICQ	 				=>	"Contacting member via ICQ",
WHERE_AOL 				=>	"Contacting member via AIM",
WHERE_Profile				=>	"Viewing Members Profile",
WHERE_Stats				=>	"Viewing Stats",
WHERE_ModCP				=>	"Using Moderators CP:",
member_name				=>	"Member Name",
guest						=>	"Guest",
board_index					=>	"Viewing Board Index",
n_a						=>	"[ N/A ]",
pages						=>	"Pages:",
'time'						=>	"Time",
where					=>	"Location",
user_ops					=>	"Options",
page_title					=>	"Online Users",

);
?>